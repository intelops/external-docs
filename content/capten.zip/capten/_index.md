---
redirect_to_latest: true # Redirects the user to the latest version of this topic if they are on the root page itself.
latest_version: 0.0.1 # you must specify the latest version of this topic
---